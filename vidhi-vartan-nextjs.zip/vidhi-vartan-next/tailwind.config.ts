import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        paper: '#e6e7e8',
        'paper-2': '#dfe1e3',
        'paper-3': '#f3f4f5',
        ink: '#364c69',
        'ink-2': '#2a3c54',
        'ink-3': '#1f2c3f',
        accent: '#009279',
        'accent-dark': '#00715e',
        gold: '#b08a4a',
      },
      fontFamily: {
        serif: ['var(--font-playfair)', 'Georgia', 'serif'],
        edit: ['var(--font-cormorant)', 'Georgia', 'serif'],
        sans: ['var(--font-inter)', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};

export default config;
