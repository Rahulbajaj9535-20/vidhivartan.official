// Single source of truth for all site content.
// Edit values here and the entire site updates.

export const company = {
  name: 'Vidhi Vartan',
  tagline: 'Transforming Legal Expertise into Digital Authority',
  email: 'official.vidhivartan@gmail.com',
  phone: '+91 93510 22410',
  whatsapp: '919351022410', // No spaces or symbols, for wa.me URLs
  location: 'Jaipur, Rajasthan, India',
  designer: 'Designed By Rahul Bajaj',
};

export const painPoints = [
  'Limited online visibility despite years of practice.',
  'Unstructured or incomplete LinkedIn profiles.',
  'Absence of a professional website or web presence.',
  'Inconsistent legal content & infrequent publication.',
  'Lack of time to manage digital presence regularly.',
];

export const solutions = [
  'Build a strong, distinctive professional identity.',
  'Showcase legal expertise effectively & accurately.',
  'Maintain consistent presence across all platforms.',
  'Manage profiles, content and websites on your behalf.',
  'Free your time — focus on practice, not platforms.',
];

export const services = [
  {
    num: 'i.',
    title: 'Website Design & Maintenance',
    teaser: 'Professional websites for advocates and law firms.',
    description:
      'A structured digital home that conveys credibility — with practice areas, profile, judgments, and insights presented with editorial precision.',
    features: [
      'Custom design tailored to legal practice',
      'Mobile-responsive & SEO optimised',
      'Continuous updates, security & monitoring',
      'Practice-area pages & case studies',
    ],
    icon: 'website',
  },
  {
    num: 'ii.',
    title: 'LinkedIn Optimisation & Posts',
    teaser: 'A LinkedIn presence that mirrors your courtroom authority.',
    description:
      'A complete profile rework paired with a steady cadence of legal commentary — published on your behalf, in your voice.',
    features: [
      'Profile rewrite, banner & headline strategy',
      'Regular legal posts & commentary',
      'Judgment summaries & case updates',
      'Engagement & connection management',
    ],
    icon: 'linkedin',
  },
  {
    num: 'iii.',
    title: 'Legal Content Writing',
    teaser: 'Articles, blogs, case summaries — drafted with legal precision.',
    description:
      'Editorially-reviewed legal writing that communicates your expertise with clarity, accuracy and authority.',
    features: [
      'Articles, blogs & opinion pieces',
      'Case briefs & judgment analysis',
      'Practice-area thought leadership',
      'Professionally proofed & cited',
    ],
    icon: 'document',
  },
  {
    num: 'iv.',
    title: 'Logo Design & Brand Identity',
    teaser: 'Considered visual identities for legal practitioners.',
    description:
      'Distinctive marks, typography systems and brand guidelines that signal heritage, gravitas and modern professionalism.',
    features: [
      'Bespoke logo design with revisions',
      'Typography & colour palette system',
      'Letterhead, business card & stationery',
      'Brand guidelines document',
    ],
    icon: 'logo',
  },
  {
    num: 'v.',
    title: 'Social Media Management',
    teaser: 'Comprehensive presence across professional channels.',
    description:
      'Consistent, impactful management of your digital channels where peers, clients and the legal community are watching.',
    features: [
      'Content calendar & scheduling',
      'Cross-platform consistency',
      'Engagement & community management',
      'Analytics & growth reporting',
    ],
    icon: 'social',
  },
];

export const process = [
  {
    step: '01',
    title: 'Profile Analysis',
    description: 'Understanding your professional background, expertise and ambitions in depth.',
  },
  {
    step: '02',
    title: 'Strategy Development',
    description: 'Crafting a customised digital positioning plan tailored to your practice.',
  },
  {
    step: '03',
    title: 'Content Creation',
    description: 'Developing structured legal content — articulate, accurate and on-brand.',
  },
  {
    step: '04',
    title: 'Platform Execution',
    description: 'Implementing across LinkedIn, websites and other professional channels.',
  },
  {
    step: '05',
    title: 'Ongoing Management',
    description: 'Sustaining consistency, monitoring growth and refining the strategy.',
  },
];

export const leadership = [
  {
    slug: 'suyash',
    name: 'Suyash Kuvera',
    role: 'Founder & Legal Strategy Head',
    bio: 'Leads vision, legal positioning and client advisory.',
    image: '/team/suyash.jpg',
    linkedin: 'https://www.linkedin.com/in/suyash-kuvera-6a17a12a4/',
    phone: '+91 93510 22410',
    phoneTel: '+919351022410',
  },
  {
    slug: 'yuvraj',
    name: 'Yuvraj Bishnoi',
    role: 'Co-Founder & Business Development',
    bio: 'Handles growth strategy and client relations.',
    image: '/team/yuvraj.jpg',
    linkedin: 'https://www.linkedin.com/in/yuvrajbishnoi/',
  },
  {
    slug: 'rahul',
    name: 'Rahul Bajaj',
    role: 'Head — Technology & Design',
    bio: 'Manages website development and design.',
    image: '/team/rahul.jpg',
    linkedin: 'https://www.linkedin.com/in/rahulbajaj2020/',
    phone: '+91 91459 55691',
    phoneTel: '+919145955691',
  },
];

export const operations = [
  {
    slug: 'deeksha',
    name: 'Deeksha Dhabhai',
    role: 'Executive — Legal Content Writing',
    image: '/team/deeksha.jpg',
    linkedin: 'https://www.linkedin.com/in/deeksha-dhabhai-1313a83b1/',
  },
  {
    slug: 'ansuiya',
    name: 'Ansuiya Bishnoi',
    role: 'Manager — LinkedIn & Content',
    image: '/team/ansuiya.jpg',
    linkedin: 'https://www.linkedin.com/in/ansuiya-bishnoi-0347282a5/',
  },
  {
    slug: 'lakshmi',
    name: 'Lakshmi Meena',
    role: 'Manager — Administration & Content',
    image: '/team/lakshmi.jpg',
    linkedin: 'https://www.linkedin.com/in/lakshmi-meena-52354a30b/',
  },
  {
    slug: 'nupur',
    name: 'Nupur Sharma',
    role: 'Executive — Website Content',
    image: '/team/nupur.jpg',
    linkedin: 'https://www.linkedin.com/in/nupur-sharma-0a9434284/',
  },
];

export const pricingPlans = [
  {
    num: 'i.',
    name: 'Starter',
    price: '5,000',
    period: '/ month',
    tagline: 'For solo practitioners building first visibility.',
    features: [
      'LinkedIn profile optimisation',
      '4 LinkedIn posts per month',
      'Basic legal content support',
    ],
    featured: false,
  },
  {
    num: 'ii.',
    name: 'Growth',
    price: '7,500',
    period: '/ month',
    tagline: 'Consistent presence with regular legal commentary.',
    features: [
      'LinkedIn profile optimisation',
      '6 LinkedIn posts per month',
      '3 legal articles / blogs',
      'Case updates & summaries',
    ],
    featured: false,
  },
  {
    num: 'iii.',
    name: 'Professional',
    price: '12,500',
    period: '/ month',
    tagline: 'Comprehensive content with strategic positioning.',
    features: [
      'LinkedIn profile optimisation',
      '8 posts + 5 articles per month',
      'Website content updates',
      'Digital positioning strategy',
    ],
    featured: true,
  },
  {
    num: 'iv.',
    name: 'Premium',
    price: '16,000',
    plus: true,
    period: '/ month',
    tagline: 'Full-service digital presence for established firms.',
    features: [
      'Complete LinkedIn management',
      'Website management',
      '16+ content pieces per month',
      'Full digital presence strategy',
    ],
    featured: false,
  },
];

export const oneTimeServices = [
  {
    name: 'Website Design',
    priceLow: '15,000',
    priceHigh: '40,000',
    description: 'Custom-built professional website for advocates and law firms.',
  },
  {
    name: 'Logo Design',
    priceLow: '2,500',
    priceHigh: '7,000',
    description: 'Distinctive visual identity rooted in legal heritage.',
  },
  {
    name: 'LinkedIn Optimisation',
    priceLow: '2,500',
    priceHigh: '5,000',
    description: 'One-time profile rebuild and structural rework.',
  },
  {
    name: 'Legal Articles',
    priceLow: '1,500',
    priceHigh: '3,000',
    description: 'Per article — researched, drafted and editorially reviewed.',
  },
];

export const navItems = [
  { label: 'About', href: '#about' },
  { label: 'Why Us', href: '#problem' },
  { label: 'Services', href: '#services' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Process', href: '#process' },
  { label: 'Team', href: '#team' },
  { label: 'Articles', href: '#articles' },
  { label: 'Contact', href: '#contact' },
];

export const articles = [
  {
    slug: 'article-1',
    num: 'i.',
    eyebrow: 'Personal Branding',
    title: 'Importance of Social Media Platforms for Professional Growth',
    excerpt: 'LinkedIn is more than a digital resume. For young legal professionals, it is the stage on which careers are built — one connection at a time.',
    readTime: '5 min read',
  },
  {
    slug: 'article-2',
    num: 'ii.',
    eyebrow: 'Networking',
    title: 'Digital Networking: Building a Referral Network in a Virtual World',
    excerpt: 'In the legal profession, trust is the currency of success. Here is how Indian advocates can build a credible referral network online — within BCI rules.',
    readTime: '7 min read',
  },
  {
    slug: 'article-3',
    num: 'iii.',
    eyebrow: 'Digital Strategy',
    title: 'Importance of Website Optimisation',
    excerpt: '96% of consumers seeking legal advice begin on a search engine. Without an optimised website, an advocate is invisible to the modern client.',
    readTime: '6 min read',
  },
];
