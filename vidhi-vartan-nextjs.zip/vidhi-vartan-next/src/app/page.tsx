import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Introduction from '@/components/Introduction';
import ProblemSolution from '@/components/ProblemSolution';
import Services from '@/components/Services';
import Pricing from '@/components/Pricing';
import SectionDivider from '@/components/SectionDivider';
import Process from '@/components/Process';
import Team from '@/components/Team';
import Compliance from '@/components/Compliance';
import Articles from '@/components/Articles';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Introduction />
        <ProblemSolution />
        <Services />
        <Pricing />
        <SectionDivider />
        <Process />
        <Team />
        <Compliance />
        <Articles />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
