import type { Metadata, Viewport } from 'next';
import { Inter, Playfair_Display, Cormorant_Garamond } from 'next/font/google';
import WhatsAppFab from '@/components/WhatsAppFab';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
  weight: ['300', '400', '500', '600', '700'],
});

const playfair = Playfair_Display({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-playfair',
  weight: ['400', '500', '600', '700', '800'],
  style: ['normal', 'italic'],
});

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-cormorant',
  weight: ['400', '500'],
  style: ['normal', 'italic'],
});

export const metadata: Metadata = {
  title: 'Vidhi Vartan — Transforming Legal Expertise into Digital Authority',
  description:
    "India's specialised digital presence platform dedicated exclusively to the legal fraternity. Websites, LinkedIn optimisation, legal content & branding for advocates and law firms.",
  keywords: [
    'legal branding India',
    'lawyer website design',
    'advocate digital presence',
    'LinkedIn for advocates',
    'law firm website',
    'legal content writing',
    'Jaipur',
  ],
  authors: [{ name: 'Vidhi Vartan' }],
  icons: {
    icon: '/logo/vidhi-vartan-logo.png',
    apple: '/logo/vidhi-vartan-logo.png',
  },
  openGraph: {
    title: 'Vidhi Vartan',
    description: 'Transforming Legal Expertise into Digital Authority',
    type: 'website',
    locale: 'en_IN',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: '#364c69',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${playfair.variable} ${cormorant.variable}`}
    >
      <body className="font-sans">
        {children}
        <WhatsAppFab />
      </body>
    </html>
  );
}
