import Image from 'next/image';
import Link from 'next/link';
import { company } from '@/data/site';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-ink text-paper/85">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 pt-20 pb-10">
        <div className="grid lg:grid-cols-12 gap-10 pb-14 border-b border-paper/15">
          <div className="lg:col-span-5">
            <div className="flex items-center gap-3 mb-5">
              <Image
                src="/logo/vidhi-vartan-logo.png"
                alt="Vidhi Vartan"
                width={48}
                height={48}
                className="h-12 w-auto"
              />
              <span className="font-serif text-2xl font-semibold text-paper leading-none">
                Vidhi Vartan
              </span>
            </div>
            <p className="font-edit italic text-2xl text-paper/85 leading-snug max-w-md">
              &ldquo;Your strategic partner in building professional digital presence.&rdquo;
            </p>
            <p className="mt-6 text-paper/70 text-sm leading-relaxed max-w-md">
              Transforming Legal Expertise into Digital Authority — India&apos;s specialised digital
              presence platform for the legal fraternity.
            </p>
          </div>

          <div className="lg:col-span-2">
            <p className="serial-bar text-accent mb-4">Navigate</p>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#about" className="text-paper/80 hover:text-accent">About</Link>
              </li>
              <li>
                <Link href="#services" className="text-paper/80 hover:text-accent">Services</Link>
              </li>
              <li>
                <Link href="#pricing" className="text-paper/80 hover:text-accent">Pricing</Link>
              </li>
              <li>
                <Link href="#process" className="text-paper/80 hover:text-accent">Process</Link>
              </li>
              <li>
                <Link href="#team" className="text-paper/80 hover:text-accent">Team</Link>
              </li>
              <li>
                <Link href="#articles" className="text-paper/80 hover:text-accent">Articles</Link>
              </li>
            </ul>
          </div>

          <div className="lg:col-span-2">
            <p className="serial-bar text-accent mb-4">Services</p>
            <ul className="space-y-2 text-sm text-paper/80">
              <li>Website Design</li>
              <li>LinkedIn Management</li>
              <li>Legal Content</li>
              <li>Brand Identity</li>
            </ul>
          </div>

          <div className="lg:col-span-3">
            <p className="serial-bar text-accent mb-4">Office</p>
            <address className="not-italic text-sm text-paper/85 leading-relaxed space-y-3">
              <div className="flex items-start gap-3">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  className="text-accent flex-shrink-0 mt-0.5"
                >
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
                <span>{company.location}</span>
              </div>
              <div className="flex items-start gap-3">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  className="text-accent flex-shrink-0 mt-0.5"
                >
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                </svg>
                <a href={`tel:${company.whatsapp}`}>{company.phone}</a>
              </div>
              <div className="flex items-start gap-3">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  className="text-accent flex-shrink-0 mt-0.5"
                >
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <path d="m22 6-10 7L2 6" />
                </svg>
                <a href={`mailto:${company.email}`} className="break-all">{company.email}</a>
              </div>
            </address>
          </div>
        </div>

        <div className="pt-8 text-center text-xs text-paper/55 tracking-wider">
          <p>© {year} Vidhi Vartan. All rights reserved.</p>
          <p className="mt-2 text-paper/45">{company.designer}</p>
        </div>
      </div>
    </footer>
  );
}
