import Link from 'next/link';

export default function Hero() {
  return (
    <section id="home" className="paper-texture relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 pt-16 lg:pt-24 pb-20 lg:pb-28">
        <div className="grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-8">
            <p className="eyebrow mb-6">
              Specialised Digital Presence · For the Legal Fraternity
            </p>
            <h1 className="display hero-headline">
              Transforming
              <br />
              Legal Expertise into
              <br />
              <em>Digital Authority.</em>
            </h1>
            <p className="mt-8 max-w-2xl text-lg lg:text-xl leading-relaxed text-ink-2/85 font-light">
              India&apos;s specialised digital presence platform dedicated exclusively to the legal
              fraternity — helping advocates, law firms and legal institutions establish a structured,
              credible and authoritative presence online.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link href="#contact" className="btn btn-primary">
                Get in Touch <span className="arrow">→</span>
              </Link>
              <Link href="#services" className="btn btn-ghost">
                View Services <span className="arrow">→</span>
              </Link>
            </div>
          </div>

          <aside className="lg:col-span-4 lg:pl-8 lg:border-l border-ink/15">
            <p className="serial-bar mb-4">A Word From Our Founders</p>
            <p className="font-edit text-2xl lg:text-[1.6rem] leading-snug text-ink italic">
              &ldquo;Excellence in advocacy deserves an equally considered presence beyond the courtroom.&rdquo;
            </p>
            <div className="mt-6 hairline pt-5 grid grid-cols-3 gap-3 text-center">
              <div>
                <div className="font-serif text-3xl text-ink">5+</div>
                <div className="text-xs uppercase tracking-widest text-ink-2/70 mt-1">Services</div>
              </div>
              <div>
                <div className="font-serif text-3xl text-ink">100%</div>
                <div className="text-xs uppercase tracking-widest text-ink-2/70 mt-1">BCI Compliant</div>
              </div>
              <div>
                <div className="font-serif text-3xl text-ink">1:1</div>
                <div className="text-xs uppercase tracking-widest text-ink-2/70 mt-1">Bespoke</div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}
