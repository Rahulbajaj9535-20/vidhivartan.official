'use client';

import Link from 'next/link';
import { useState, useEffect, useRef } from 'react';
import { services } from '@/data/site';
import ServiceIcon from './ServiceIcon';

export default function Services() {
  const [flippedIdx, setFlippedIdx] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Tap outside to close
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (!containerRef.current?.contains(e.target as Node)) {
        setFlippedIdx(null);
      }
    };
    document.addEventListener('click', onClick);
    return () => document.removeEventListener('click', onClick);
  }, []);

  const handleCardClick = (e: React.MouseEvent, idx: number) => {
    if ((e.target as HTMLElement).closest('.back-cta')) return;
    setFlippedIdx((curr) => (curr === idx ? null : idx));
  };

  return (
    <section id="services" className="border-t border-ink/15">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-28">
        <div className="grid lg:grid-cols-12 gap-10 mb-14">
          <div className="lg:col-span-7">
            <p className="eyebrow mb-5">Services</p>
            <h2 className="section-headline display">
              A practice tailored
              <br />
              to <em>the legal practice.</em>
            </h2>
          </div>
          <div className="lg:col-span-5 lg:pt-10">
            <p className="text-lg leading-relaxed text-ink-2/85 font-light">
              Each engagement is bespoke. Below, the disciplines through which we craft and sustain
              your digital authority.
            </p>
          </div>
        </div>

        <div ref={containerRef} className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <article
              key={s.num}
              className={`service-card-flip ${flippedIdx === i ? 'is-flipped' : ''}`}
              tabIndex={0}
              role="button"
              aria-label={`${s.title} - tap for details`}
              onClick={(e) => handleCardClick(e, i)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setFlippedIdx((c) => (c === i ? null : i));
                } else if (e.key === 'Escape') {
                  setFlippedIdx(null);
                }
              }}
            >
              <div className="service-card-front">
                <div className="flex items-start justify-between mb-6">
                  <span className="service-num text-3xl">{s.num}</span>
                  <span className="text-accent">
                    <ServiceIcon name={s.icon as 'website' | 'linkedin' | 'document' | 'logo' | 'social'} />
                  </span>
                </div>
                <h3 className="font-serif text-2xl text-ink mb-3">{s.title}</h3>
                <p className="text-ink-2/85 leading-relaxed text-sm">{s.teaser}</p>
                <span className="service-explore-cue">
                  <span>Explore</span>
                  <span className="cue-arrow">→</span>
                </span>
              </div>

              <div className="service-card-back">
                <div className="back-inner">
                  <div className="flex items-start justify-between mb-4">
                    <span className="service-num-back">{s.num}</span>
                    <span className="back-icon">
                      <ServiceIcon name={s.icon as 'website' | 'linkedin' | 'document' | 'logo' | 'social'} />
                    </span>
                  </div>
                  <h3 className="font-serif text-xl mb-3 text-paper leading-tight">{s.title}</h3>
                  <p className="back-desc">{s.description}</p>
                  <ul className="back-features">
                    {s.features.map((f) => (
                      <li key={f}>{f}</li>
                    ))}
                  </ul>
                  <Link href="#contact" className="back-cta" onClick={(e) => e.stopPropagation()}>
                    Enquire <span className="arrow">→</span>
                  </Link>
                </div>
              </div>
            </article>
          ))}

          {/* Bespoke (6th) card */}
          <article
            className="bg-ink text-paper p-8 border border-ink relative overflow-hidden"
            style={{ minHeight: 280 }}
          >
            <div className="flex items-start justify-between mb-6">
              <span className="service-num text-3xl" style={{ color: 'var(--gold)' }}>vi.</span>
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.4"
                style={{ color: 'var(--accent)' }}
              >
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </div>
            <h3 className="font-serif text-2xl mb-3 text-white">Bespoke Engagements</h3>
            <p className="text-paper/80 leading-relaxed text-sm mb-6">
              Particular requirements? Reputation-management briefs, multilingual content, chamber
              rebrands. We build custom retainers around your practice.
            </p>
            <Link
              href="#contact"
              className="inline-flex items-center gap-2 text-accent hover:gap-3 transition-all text-sm font-medium tracking-wider uppercase"
            >
              Discuss a Brief →
            </Link>
          </article>
        </div>
      </div>
    </section>
  );
}
