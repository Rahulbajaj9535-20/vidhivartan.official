export default function Compliance() {
  return (
    <section className="border-t border-ink/15 bg-paper-2">
      <div className="max-w-5xl mx-auto px-6 lg:px-12 py-16 lg:py-20 text-center">
        <div className="text-gold text-2xl tracking-[0.4em] mb-6">⚖ · ⚖ · ⚖</div>
        <p className="eyebrow">Ethical Compliance</p>
        <h3 className="display section-headline mt-4">
          Practising within the bounds of the <em>Bar Council of India.</em>
        </h3>
        <p className="mt-7 text-lg leading-relaxed text-ink-2/85 max-w-3xl mx-auto font-light">
          All services rendered by Vidhi Vartan are designed in strict accordance with the
          professional standards and guidelines prescribed by the Bar Council of India — ensuring
          professional dignity, ethical representation and credible communication, without exception.
        </p>
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <span className="chip-divider">Professional Dignity</span>
          <span className="chip-divider">Ethical Representation</span>
          <span className="chip-divider">Credible Communication</span>
        </div>
      </div>
    </section>
  );
}
