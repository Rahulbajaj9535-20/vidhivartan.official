import { leadership, operations } from '@/data/site';
import MemberCard from './MemberCard';

export default function Team() {
  return (
    <section id="team" className="border-t border-ink/15 bg-paper-2">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-28">
        <div className="grid lg:grid-cols-12 gap-10 mb-16">
          <div className="lg:col-span-6">
            <p className="eyebrow mb-5">The Bench</p>
            <h2 className="section-headline display">
              A team at the
              <br />
              intersection of <em>law</em>
              <br />
              and <em>communication.</em>
            </h2>
          </div>
          <div className="lg:col-span-5 lg:col-start-8 lg:pt-12">
            <p className="text-lg leading-relaxed text-ink-2/85 font-light">
              Vidhi Vartan is driven by a team of legal professionals and digital specialists working
              at the intersection of law, communication and digital strategy.
            </p>
          </div>
        </div>

        <div className="flex items-baseline justify-between mb-8 hairline pt-6">
          <p className="serial-bar">Leadership</p>
          <span className="font-edit italic text-ink/50 text-sm"></span>
        </div>
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 mb-20">
          {leadership.map((m) => (
            <MemberCard key={m.slug} member={m} variant="leadership" />
          ))}
        </div>

        <div className="flex items-baseline justify-between mb-8 hairline pt-6">
          <p className="serial-bar">Operations & Execution</p>
          <span className="font-edit italic text-ink/50 text-sm"></span>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-7">
          {operations.map((m) => (
            <MemberCard key={m.slug} member={m} variant="operations" />
          ))}
        </div>
      </div>
    </section>
  );
}
