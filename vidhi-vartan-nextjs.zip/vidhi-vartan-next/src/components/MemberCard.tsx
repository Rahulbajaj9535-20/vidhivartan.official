import Image from 'next/image';

type Member = {
  slug: string;
  name: string;
  role: string;
  bio?: string;
  image: string;
  linkedin?: string;
  phone?: string;
  phoneTel?: string;
};

export default function MemberCard({
  member,
  variant,
}: {
  member: Member;
  variant: 'leadership' | 'operations';
}) {
  const isLeader = variant === 'leadership';
  const hasLinkedin = !!member.linkedin;
  const hasPhone = !!member.phone && !!member.phoneTel;
  const isInteractive = hasLinkedin || hasPhone;

  return (
    <article className={`member-card ${isInteractive ? 'member-card-rahul' : ''}`}>
      <div className="member-portrait-wrap relative">
        <Image
          src={member.image}
          alt={member.name}
          fill
          className="object-cover"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
        />
        {hasPhone && (
          <div className="rahul-phone-overlay">
            <a
              href={`tel:${member.phoneTel}`}
              className="rahul-phone-row"
              onClick={(e) => e.stopPropagation()}
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
              >
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
              </svg>
              <span>{member.phone}</span>
            </a>
          </div>
        )}
      </div>
      <div className="member-info">
        {isLeader ? (
          <>
            <h4 className="font-serif text-2xl text-ink mb-1.5 leading-tight">
              {hasLinkedin ? (
                <a
                  href={member.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rahul-name-link"
                >
                  {member.name}
                  <svg
                    className="rahul-linkedin-icon"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    aria-hidden="true"
                  >
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.063 2.063 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                  </svg>
                </a>
              ) : (
                member.name
              )}
            </h4>
            <p
              className="text-accent text-sm font-medium mb-3 uppercase"
              style={{ letterSpacing: '0.08em' }}
            >
              {member.role}
            </p>
            {member.bio && <p className="text-ink-2/80 text-sm leading-relaxed">{member.bio}</p>}
          </>
        ) : (
          <>
            <h5 className="font-serif text-xl text-ink mb-1.5 leading-tight">
              {hasLinkedin ? (
                <a
                  href={member.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rahul-name-link"
                >
                  {member.name}
                  <svg
                    className="rahul-linkedin-icon"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    aria-hidden="true"
                  >
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.063 2.063 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                  </svg>
                </a>
              ) : (
                member.name
              )}
            </h5>
            <p
              className="text-accent text-xs font-medium uppercase"
              style={{ letterSpacing: '0.08em' }}
            >
              {member.role}
            </p>
          </>
        )}
      </div>
    </article>
  );
}
