'use client';

import { useState, FormEvent } from 'react';
import { company } from '@/data/site';

export default function Contact() {
  const [status, setStatus] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    const name = (formData.get('name') as string)?.trim() || '';
    const email = (formData.get('email') as string)?.trim() || '';
    const phone = (formData.get('phone') as string)?.trim() || '';
    const firm = (formData.get('firm') as string)?.trim() || '';
    const message = (formData.get('message') as string)?.trim() || '';

    const lines = ['*New Enquiry — Vidhi Vartan*', '', `*Name:* ${name}`, `*Email:* ${email}`];
    if (phone) lines.push(`*Phone:* ${phone}`);
    if (firm) lines.push(`*Firm / Chamber:* ${firm}`);
    lines.push('', '*Message:*', message);

    const text = encodeURIComponent(lines.join('\n'));
    const url = `https://wa.me/${company.whatsapp}?text=${text}`;

    setStatus({
      message: 'Opening WhatsApp… please tap Send to deliver your enquiry.',
      type: 'success',
    });

    window.open(url, '_blank');

    setTimeout(() => {
      form.reset();
      setTimeout(() => setStatus(null), 4000);
    }, 1200);
  };

  return (
    <section id="contact" className="border-t border-ink/15">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-28">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <p className="eyebrow mb-5">Get in Touch</p>
            <h2 className="section-headline display">
              Begin a <em>considered</em> conversation.
            </h2>
            <p className="mt-6 text-lg leading-relaxed text-ink-2/85 font-light max-w-md">
              We would be pleased to assist you in building your professional digital presence. Reach
              out, and we will respond within one working day.
            </p>

            <div className="mt-10 space-y-5">
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(company.location)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-4 group"
              >
                <div className="w-11 h-11 border border-ink/25 flex items-center justify-center text-ink group-hover:border-accent group-hover:text-accent transition">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                </div>
                <div>
                  <p className="serial-bar mb-1">Office</p>
                  <p className="font-serif text-lg text-ink">Jaipur, Rajasthan</p>
                </div>
              </a>
              <a href={`tel:${company.whatsapp}`} className="flex items-start gap-4 group">
                <div className="w-11 h-11 border border-ink/25 flex items-center justify-center text-ink group-hover:border-accent group-hover:text-accent transition">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                  </svg>
                </div>
                <div>
                  <p className="serial-bar mb-1">Telephone</p>
                  <p className="font-serif text-lg text-ink">{company.phone}</p>
                </div>
              </a>
              <a href={`mailto:${company.email}`} className="flex items-start gap-4 group">
                <div className="w-11 h-11 border border-ink/25 flex items-center justify-center text-ink group-hover:border-accent group-hover:text-accent transition">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                    <path d="m22 6-10 7L2 6" />
                  </svg>
                </div>
                <div>
                  <p className="serial-bar mb-1">Correspondence</p>
                  <p className="font-serif text-lg text-ink break-all">{company.email}</p>
                </div>
              </a>
            </div>
          </div>

          <div className="lg:col-span-6 lg:col-start-7">
            <form
              id="enquiryForm"
              className="bg-paper-3 border border-ink/15 p-8 lg:p-10"
              onSubmit={handleSubmit}
            >
              <h3 className="font-serif text-2xl text-ink mb-3">Brief us on your practice.</h3>
              <p className="form-email-note">
                <span>Or write to us directly at</span>
                <a href={`mailto:${company.email}`}>{company.email}</a>
              </p>

              <div className="grid sm:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="form-label" htmlFor="f-name">
                    Full Name
                  </label>
                  <input id="f-name" name="name" type="text" className="form-input" required />
                </div>
                <div>
                  <label className="form-label" htmlFor="f-email">
                    Email Address
                  </label>
                  <input id="f-email" name="email" type="email" className="form-input" required />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="form-label" htmlFor="f-phone">
                    Telephone
                  </label>
                  <input id="f-phone" name="phone" type="tel" className="form-input" />
                </div>
                <div>
                  <label className="form-label" htmlFor="f-firm">
                    Firm / Chamber
                  </label>
                  <input id="f-firm" name="firm" type="text" className="form-input" />
                </div>
              </div>

              <div className="mb-8">
                <label className="form-label" htmlFor="f-msg">
                  Message
                </label>
                <textarea
                  id="f-msg"
                  name="message"
                  rows={4}
                  className="form-input"
                  placeholder="Tell us about your practice and what you would like to achieve..."
                  required
                />
              </div>

              <button type="submit" className="btn-whatsapp w-full sm:w-auto">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" />
                </svg>
                <span>Send via WhatsApp</span>
                <span className="arrow">→</span>
              </button>
              {status && (
                <p
                  className={`text-sm mt-5 leading-relaxed font-medium ${
                    status.type === 'success' ? 'text-accent' : 'text-red-700'
                  }`}
                >
                  {status.message}
                </p>
              )}
              <p className="text-xs text-ink-2/60 mt-5 leading-relaxed">
                By submitting, you consent to be contacted via WhatsApp regarding your enquiry. Your
                information is kept confidential and used solely for advisory purposes.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
