import { process } from '@/data/site';

export default function Process() {
  return (
    <section
      id="process"
      className="bg-ink text-paper paper-texture relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-28">
        <div className="text-center mb-16">
          <p className="eyebrow" style={{ color: 'var(--accent)' }}>
            Process
          </p>
          <h2 className="section-headline display mt-4 text-paper">
            A method in <em style={{ color: 'var(--accent)' }}>five movements.</em>
          </h2>
          <p className="mt-5 max-w-2xl mx-auto text-lg text-paper/75 font-light">
            Every engagement follows a deliberate sequence — from understanding the practitioner to
            sustaining the presence we build together.
          </p>
        </div>

        {/* Desktop horizontal timeline */}
        <div className="hidden lg:block relative">
          <div className="absolute left-0 right-0 top-[42px] h-px bg-paper/25" />
          <div className="grid grid-cols-5 gap-6">
            {process.map((p) => (
              <div key={p.step} className="process-node text-center">
                <div className="flex justify-center mb-6">
                  <div className="node-dot" />
                </div>
                <p className="serial-bar text-accent mb-2">Step {p.step}</p>
                <h4 className="font-serif text-xl mb-3">{p.title}</h4>
                <p className="text-paper/70 text-sm leading-relaxed">{p.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile vertical timeline */}
        <div className="lg:hidden relative">
          <div className="absolute left-[9px] top-2 bottom-2 w-px bg-paper/25" />
          <div className="space-y-8">
            {process.map((p) => (
              <div key={p.step} className="process-node pl-10 relative">
                <div className="absolute left-0 top-1">
                  <div className="node-dot" />
                </div>
                <p className="serial-bar text-accent mb-1">Step {p.step}</p>
                <h4 className="font-serif text-xl mb-2">{p.title}</h4>
                <p className="text-paper/70 text-sm leading-relaxed">{p.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
