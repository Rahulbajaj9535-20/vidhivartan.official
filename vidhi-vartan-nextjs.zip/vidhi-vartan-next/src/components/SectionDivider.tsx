export default function SectionDivider() {
  return (
    <div className="bg-ink py-1">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="section-divider-light">
          <span className="divider-ornament">◆</span>
        </div>
      </div>
    </div>
  );
}
