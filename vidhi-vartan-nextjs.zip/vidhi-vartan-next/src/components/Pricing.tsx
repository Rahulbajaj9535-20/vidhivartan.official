import Link from 'next/link';
import { pricingPlans, oneTimeServices } from '@/data/site';

export default function Pricing() {
  return (
    <section
      id="pricing"
      className="border-t border-ink/15 bg-ink text-paper paper-texture relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-28">
        <div className="text-center mb-14">
          <p className="eyebrow" style={{ color: 'var(--accent)' }}>
            Pricing & Engagement
          </p>
          <h2 className="section-headline display mt-4 text-paper">
            Engagements tailored to <em style={{ color: 'var(--accent)' }}>your practice.</em>
          </h2>
          <p className="mt-5 max-w-2xl mx-auto text-lg text-paper/75 font-light">
            Vidhi Vartan offers flexible engagement models for advocates, law firms and legal
            institutions — from a focused starter retainer to a fully managed digital presence.
          </p>
        </div>

        <div
          className="flex items-baseline justify-between mb-8 pt-6"
          style={{ borderTop: '1px solid rgba(230,231,232,0.18)' }}
        >
          <p className="serial-bar" style={{ color: 'var(--accent)' }}>
            Monthly Retainership Plans
          </p>
          <span className="font-edit italic text-paper/55 text-sm">Four tiers · GST not included</span>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-6">
          {pricingPlans.map((p) => (
            <article
              key={p.name}
              className={`pricing-card ${p.featured ? 'pricing-card-featured' : ''}`}
            >
              <span className="corner-tl" />
              <span className="corner-tr" />
              <span className="corner-bl" />
              <span className="corner-br" />
              {p.featured && <span className="featured-tag">Most Recommended</span>}
              <p className="plan-eyebrow">Plan {p.num}</p>
              <h3 className="plan-name">{p.name}</h3>
              <div className="plan-price">
                <span className="rupee">₹</span>
                <span className="amount">{p.price}</span>
                {p.plus && <span className="plus">+</span>}
                <span className="period">{p.period}</span>
              </div>
              <p className="plan-tagline">{p.tagline}</p>
              <ul className="plan-features">
                {p.features.map((f) => (
                  <li key={f}>{f}</li>
                ))}
              </ul>
              <Link
                href="#contact"
                className={`plan-cta ${p.featured ? 'plan-cta-featured' : ''}`}
              >
                Get Started <span className="arrow">→</span>
              </Link>
            </article>
          ))}
        </div>

        <div
          className="flex items-baseline justify-between mb-8 mt-20 pt-6"
          style={{ borderTop: '1px solid rgba(230,231,232,0.18)' }}
        >
          <p className="serial-bar" style={{ color: 'var(--accent)' }}>
            One-Time Services
          </p>
          <span className="font-edit italic text-paper/55 text-sm">Project-based engagements</span>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {oneTimeServices.map((o) => (
            <div key={o.name} className="onetime-card">
              <h4 className="onetime-name">{o.name}</h4>
              <p className="onetime-price">
                ₹{o.priceLow} <span>–</span> ₹{o.priceHigh}
              </p>
              <p className="onetime-desc">{o.description}</p>
            </div>
          ))}
        </div>

        <p className="mt-12 text-center text-sm text-paper/55 italic font-edit">
          All pricing in INR. Bespoke engagements and chamber-wide retainers available on request.
        </p>
      </div>
    </section>
  );
}
