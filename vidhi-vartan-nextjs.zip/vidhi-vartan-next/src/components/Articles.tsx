import { articles } from '@/data/site';

export default function Articles() {
  return (
    <section id="articles" className="border-t border-ink/15">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-28">
        <div className="grid lg:grid-cols-12 gap-10 mb-14">
          <div className="lg:col-span-7">
            <p className="eyebrow mb-5">Articles &amp; Insights</p>
            <h2 className="section-headline display">
              Perspectives on the
              <br />
              <em>practice of presence.</em>
            </h2>
          </div>
          <div className="lg:col-span-5 lg:pt-10">
            <p className="text-lg leading-relaxed text-ink-2/85 font-light">
              Editorial pieces from the Vidhi Vartan team — covering personal branding, digital
              networking, and website strategy for the legal profession in India.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-7">
          {articles.map((a) => (
            <article key={a.slug} className="article-card">
              <div className="article-card-num">{a.num}</div>
              <p className="article-card-eyebrow">{a.eyebrow}</p>
              <h3 className="article-card-title">{a.title}</h3>
              <p className="article-card-excerpt">{a.excerpt}</p>
              <div className="article-card-footer">
                <span className="article-card-meta">{a.readTime}</span>
                <a
                  href={`/articles/${a.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="article-card-cta"
                >
                  Read Article <span className="arrow">→</span>
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
