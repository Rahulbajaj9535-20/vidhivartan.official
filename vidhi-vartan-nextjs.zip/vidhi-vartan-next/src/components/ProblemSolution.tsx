import { painPoints, solutions } from '@/data/site';

const ROMAN = ['i.', 'ii.', 'iii.', 'iv.', 'v.', 'vi.', 'vii.'];

export default function ProblemSolution() {
  return (
    <section id="problem" className="border-t border-ink/15 bg-paper-2">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-28">
        <div className="text-center mb-16">
          <p className="eyebrow">The Brief</p>
          <h2 className="section-headline display mt-4">
            Why digital presence <em>matters.</em>
          </h2>
          <p className="mt-5 max-w-2xl mx-auto text-lg text-ink-2/80 font-light">
            In today&apos;s legal landscape, professionals confront a familiar set of obstacles. We answer
            each with a structured, considered response.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
          <div>
            <div className="flex items-center justify-between mb-6">
              <p className="serial-bar">The Challenge</p>
              <span className="chip-divider">Pain Points</span>
            </div>
            <h3 className="font-serif text-2xl text-ink mb-2">What we hear, repeatedly.</h3>
            <div className="mt-4">
              {painPoints.map((p, i) => (
                <div key={i} className="pain-item">
                  <span className="pain-marker">{ROMAN[i]}</span>
                  <span className="text-lg">{p}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:pl-12 lg:border-l border-ink/15">
            <div className="flex items-center justify-between mb-6">
              <p className="serial-bar text-accent">Our Response</p>
              <span
                className="chip-divider"
                style={{ borderColor: 'var(--accent)', color: 'var(--accent)' }}
              >
                The Vidhi Vartan Way
              </span>
            </div>
            <h3 className="font-serif text-2xl text-ink mb-2">Structured digital solutions.</h3>
            <div className="mt-4">
              {solutions.map((s, i) => (
                <div key={i} className="sol-item">
                  <span className="sol-marker">✓</span>
                  <span className="text-lg">{s}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
