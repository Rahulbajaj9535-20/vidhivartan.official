export default function Introduction() {
  return (
    <section id="about" className="border-t border-ink/15">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-28">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-4">
            <p className="eyebrow mb-5">Introduction</p>
            <h2 className="section-headline display">
              A bridge between
              <br />
              <em>legal knowledge</em>
              <br />
              and digital authority.
            </h2>
          </div>
          <div className="lg:col-span-7 lg:col-start-6">
            <p className="dropcap text-lg leading-[1.85] text-ink-2/90">
              Vidhi Vartan is a specialised digital presence and legal branding platform designed
              exclusively for the legal profession. We enable advocates, law firms and legal institutions
              to establish a structured, credible and authoritative presence across digital platforms —
              including websites, LinkedIn and other professional channels.
            </p>
            <p className="mt-6 text-lg leading-[1.85] text-ink-2/90">
              In an era where professional visibility plays a critical role, legal professionals require
              structured digital platforms to present their expertise, experience and achievements with
              the dignity their practice deserves.
            </p>
            <div className="mt-10 grid sm:grid-cols-2 gap-6">
              <div className="border-l-2 border-accent pl-5">
                <p className="serial-bar mb-2">Our Vision</p>
                <p className="font-edit italic text-xl text-ink leading-snug">
                  To empower legal professionals by transforming their expertise into a credible and
                  recognised digital authority.
                </p>
              </div>
              <div className="border-l-2 border-gold pl-5">
                <p className="serial-bar mb-2">Our Mission</p>
                <p className="font-edit italic text-xl text-ink leading-snug">
                  To provide structured, professional and ethically compliant digital solutions for the
                  legal fraternity.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
