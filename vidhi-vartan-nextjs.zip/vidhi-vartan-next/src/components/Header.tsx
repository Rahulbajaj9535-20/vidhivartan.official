'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { navItems } from '@/data/site';

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-paper/95 backdrop-blur border-b border-ink/15">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-3 lg:py-5 flex items-center justify-between gap-3 flex-nowrap">
        <Link href="#home" className="flex items-center gap-2 sm:gap-3 min-w-0 flex-shrink">
          <Image
            src="/logo/vidhi-vartan-logo.png"
            alt="Vidhi Vartan"
            width={64}
            height={64}
            className="h-9 sm:h-10 md:h-12 w-auto flex-shrink-0"
            priority
          />
          <span className="font-serif text-base sm:text-xl md:text-2xl text-ink font-semibold tracking-tight leading-none whitespace-nowrap truncate">
            Vidhi Vartan
          </span>
        </Link>

        <ul className="hidden lg:flex items-center gap-9 text-sm font-medium text-ink-2 flex-shrink-0">
          {navItems.map((item) => (
            <li key={item.href}>
              <Link href={item.href} className="hover:text-accent transition">
                {item.label}
              </Link>
            </li>
          ))}
        </ul>

        <Link href="#contact" className="hidden lg:inline-flex btn btn-accent text-xs flex-shrink-0">
          Get in Touch <span className="arrow">→</span>
        </Link>

        <button
          className="lg:hidden text-ink p-2 -mr-2 flex-shrink-0"
          aria-label="Open menu"
          onClick={() => setIsOpen((v) => !v)}
        >
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 6h18M3 12h18M3 18h18" />
          </svg>
        </button>
      </nav>

      {/* Mobile nav */}
      <div
        className={`mobile-nav lg:hidden absolute left-0 right-0 top-full bg-paper border-b border-ink/15 shadow-lg ${isOpen ? 'open' : ''}`}
      >
        <ul className="flex flex-col px-6 py-6 gap-4 text-ink-2 font-medium">
          {navItems.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                className="block py-2"
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </Link>
            </li>
          ))}
          <li>
            <Link
              href="#contact"
              className="btn btn-accent text-xs justify-center mt-2"
              onClick={() => setIsOpen(false)}
            >
              Get in Touch →
            </Link>
          </li>
        </ul>
      </div>
    </header>
  );
}
