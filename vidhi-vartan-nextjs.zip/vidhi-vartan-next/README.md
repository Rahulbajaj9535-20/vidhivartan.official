# Vidhi Vartan — Next.js + Tailwind

A production-grade Next.js 14 implementation of the Vidhi Vartan website — India's specialised digital presence platform for the legal fraternity.

## Tech Stack

- **Next.js 14** (App Router, React 18, TypeScript)
- **Tailwind CSS 3** with custom design tokens
- **Optimized fonts** via `next/font/google` (Playfair Display, Inter, Cormorant Garamond)
- **Optimized images** via `next/image`
- **Static export friendly** (works on Vercel free tier, Netlify, GitHub Pages, any host)

## Features

- Fully responsive (mobile, tablet, desktop)
- Interactive service cards with flip animation
- Team contact overlays with hover/tap behavior
- Pricing cards with featured plan, corner accents, and animated checkmarks
- Editorial design language: Playfair Display, Cormorant Garamond, paper texture
- WhatsApp form integration (no backend required)
- SEO meta tags, Open Graph, theme color
- Accessibility: keyboard navigation, focus rings, `prefers-reduced-motion`
- iOS Safari optimizations (viewport-fit, no auto-zoom on form focus)

## Project Structure

```
vidhi-vartan-next/
├── public/
│   ├── logo/
│   │   └── vidhi-vartan-logo.png
│   └── team/
│       ├── suyash.jpg
│       ├── yuvraj.jpg
│       ├── rahul.jpg
│       ├── deeksha.jpg
│       ├── ansuiya.jpg
│       ├── lakshmi.jpg
│       └── nupur.jpg
├── src/
│   ├── app/
│   │   ├── globals.css        # All custom CSS (hover effects, mobile rules)
│   │   ├── layout.tsx         # Root layout, fonts, metadata
│   │   └── page.tsx           # Main page composition
│   ├── components/
│   │   ├── Header.tsx         # Sticky nav with mobile hamburger
│   │   ├── Hero.tsx
│   │   ├── Introduction.tsx
│   │   ├── ProblemSolution.tsx
│   │   ├── Services.tsx       # Interactive flip cards
│   │   ├── Pricing.tsx
│   │   ├── SectionDivider.tsx
│   │   ├── Process.tsx
│   │   ├── Team.tsx
│   │   ├── MemberCard.tsx     # With contact overlay
│   │   ├── Compliance.tsx
│   │   ├── Contact.tsx        # WhatsApp form
│   │   ├── Footer.tsx
│   │   └── ServiceIcon.tsx
│   └── data/
│       └── site.ts            # Single source of truth for content
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── next.config.js
```

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Run development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) — site loads with hot reload on edits.

### 3. Build for production

```bash
npm run build
npm run start
```

## Editing Content

All site content lives in **`src/data/site.ts`**. Update values there — every section automatically reflects changes:

- `company.email`, `company.phone`, `company.whatsapp` — Top-level brand info
- `services` — Five service cards (title, teaser, description, features)
- `pricingPlans` — Four monthly retainer tiers
- `oneTimeServices` — Project-based pricing
- `leadership` — Three founders with photos and contacts
- `operations` — Four operations members with photos and contacts
- `painPoints`, `solutions` — Why Us section
- `process` — Five-step methodology
- `navItems` — Top navigation links

To update photos, replace files in `public/team/` keeping the same filenames.

## Deployment to Vercel

### Easiest: GitHub method

1. Push this folder to a new GitHub repository
2. Go to [vercel.com/new](https://vercel.com/new)
3. Sign in with GitHub
4. Import the repo
5. Click **Deploy** — Vercel auto-detects Next.js, no config needed
6. Live in ~60 seconds at `your-project.vercel.app`

### Alternative: Vercel CLI

```bash
npm i -g vercel
vercel
```

Follow the prompts — sign in, accept defaults, deploy.

### Custom Domain

After first deploy:
1. **Project → Settings → Domains** → Add `vidhivartan.com`
2. At your registrar (GoDaddy, Namecheap, etc.), add the DNS records Vercel shows
3. HTTPS is automatic (Let's Encrypt managed by Vercel)

## Form Behavior

The contact form is wired to send enquiries via WhatsApp:
- All fields are formatted into a structured message
- Clicking "Send via WhatsApp" opens `wa.me/919351022410` with the message pre-filled
- User taps Send in WhatsApp to deliver

To change the WhatsApp number, edit `company.whatsapp` in `src/data/site.ts` (digits only, with country code, no `+` or spaces).

## Testing Checklist

Before going live, test on mobile and desktop:
- [ ] Header logo + wordmark + hamburger visible on mobile
- [ ] Mobile menu opens and closes properly
- [ ] All section anchors scroll smoothly
- [ ] Service cards flip on hover (desktop) and tap (mobile)
- [ ] Team cards show contact overlay on hover/tap
- [ ] Phone numbers in overlays open dialer when tapped
- [ ] Email addresses in overlays open mail client
- [ ] Pricing featured tag doesn't overlap the plan name
- [ ] Form WhatsApp button opens chat with pre-filled message
- [ ] Footer office icons display next to address details

## License

Proprietary. All rights reserved — Vidhi Vartan.

---

**Designed By Rahul Bajaj.**
